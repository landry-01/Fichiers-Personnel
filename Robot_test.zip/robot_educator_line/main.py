#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Port, Stop
from pybricks.tools import wait
from pybricks.robotics import DriveBase
import copy

# Initialisation de la brique EV3
ev3 = EV3Brick()

# Initialisation des moteurs et capteurs
try:
    left_motor = Motor(Port.B)
    right_motor = Motor(Port.C)
    gripper_motor = Motor(Port.A)
    line_sensor = ColorSensor(Port.S3)
    obstacle_sensor = UltrasonicSensor(Port.S1)
except OSError as e:
    ev3.screen.clear()
    ev3.screen.print("Erreur connexion:")
    ev3.screen.print(str(e))
    wait(5000)
    raise SystemExit

# Initialisation de la base motrice
robot = DriveBase(left_motor, right_motor, wheel_diameter=55.5, axle_track=104)

# Paramètres du suivi de ligne
BLACK = 8
WHITE = 85
THRESHOLD = (BLACK + WHITE) / 2
PROPORTIONAL_GAIN = 1.2
DRIVE_SPEED = 100

# Classe Node
class Node:
    def __init__(self, idx):
        self.__idx = idx
        self.__x1 = -1
        self.__x2 = -1
        self.__graph = None
        self.__neighbors = {}
        self.__distances = {}
        self.__init_neighbors()

    def get_idx(self): return self.__idx
    def get_location(self): return self.__x1, self.__x2
    def set_location(self, loc): 
        self.__x1 = loc[0]
        self.__x2 = loc[1]
    def get_neighbors(self): return copy.deepcopy(self.__neighbors)
    def get_distances(self): return copy.deepcopy(self.__distances)
    def get_graph(self): return self.__graph

    def set_graph(self, graph):
        if isinstance(graph, Grid):
            if self.__graph is None:
                self.__graph = graph
            else:
                raise RuntimeError("Node already in graph")
        else:
            raise TypeError("Graph must be Grid")

    def add_neighbor(self, node, distance, direction):
        if self.__graph is None or node.get_graph() is None:
            raise ValueError("Nodes must be in a graph before adding neighbors")
        if node.get_graph() == self.__graph:
            if node not in self.__neighbors.values() and self.__neighbors.get(direction) is None:
                self.__neighbors[direction] = node
                self.__distances[direction] = distance
                return True
            else:
                raise ValueError("Neighbor exists or direction taken: " + direction)
        raise ValueError("Not in same graph")

    def distance_to_neighbor(self, node):
        for direction, neighbor in self.__neighbors.items():
            if neighbor == node:
                return self.__distances[direction]
        return -1

    def direction_to_neighbor(self, node):
        for direction, neighbor in self.__neighbors.items():
            if neighbor == node:
                return direction
        return None

    def __init_neighbors(self):
        self.__neighbors['left'] = None
        self.__distances['left'] = -1
        self.__neighbors['right'] = None
        self.__distances['right'] = -1
        self.__neighbors['up'] = None
        self.__distances['up'] = -1
        self.__neighbors['down'] = None
        self.__distances['down'] = -1

    def __str__(self):
        return "Node " + self.__idx

# Classe Grid
class Grid:
    def __init__(self, row, col):
        self.__col = col
        self.__row = row
        self.__nodes = {}

    def get_size(self): return len(self.__nodes)
    def get_max_size(self): return self.__col * self.__row

    def add_node(self, node, row=-1, col=-1):
        if self.get_size() >= self.get_max_size():
            return False
        if not isinstance(node, Node):
            return False
        if node.get_idx() not in self.__nodes:
            node.set_graph(self)
            node.set_location((row, col))
            self.__nodes[node.get_idx()] = node
            return True
        return False

    def add_edge(self, n1, n2, distance, direction):
        if not isinstance(n1, Node): n1 = self.node_of(n1)
        if not isinstance(n2, Node): n2 = self.node_of(n2)
        if n1 is None or n2 is None:
            raise ValueError("One or both nodes not found in grid")
        success1 = n1.add_neighbor(n2, distance, direction)
        success2 = n2.add_neighbor(n1, distance, self._opposite_direction(direction))
        return success1, success2

    def node_of(self, idx):
        return self.__nodes.get(idx)

    def _opposite_direction(self, direction):
        opposites = {'left': 'right', 'right': 'left', 'up': 'down', 'down': 'up'}
        return opposites.get(direction, direction)

    def __str__(self):
        return "Grid [size=" + str(self.get_size()) + "]"

# Fonction pour suivre un segment du chemin
def follow_segment(from_node, to_node, direction, distance, is_return=False):
    ev3.screen.clear()
    ev3.screen.print("De " + from_node.get_idx() + " à " + to_node.get_idx())
    ev3.screen.print(direction + ": " + str(distance) + "mm")

    # Ajustement de la direction (inversée pour le retour)
    if is_return:
        if direction == "right":
            robot.turn(-90)  # Tourner à gauche
        elif direction == "down":
            robot.turn(-90)  # Tourner à gauche
        elif direction == "left":
            robot.turn(90)   # Tourner à droite
        elif direction == "up":
            robot.turn(90)   # Tourner à droite
    else:
        if direction == "right":
            robot.turn(90)
        elif direction == "down":
            robot.turn(90)
        elif direction == "left":
            robot.turn(-90)
        elif direction == "up":
            robot.turn(-90)

    # Suivi de la ligne sur la distance spécifiée
    pointer = robot.distance()
    a = 0
    while (robot.distance() - pointer) < distance:
        deviation = line_sensor.reflection() - THRESHOLD
        turn_rate = PROPORTIONAL_GAIN * deviation
        robot.drive(DRIVE_SPEED, turn_rate)
        
        # Gestion des obstacles et de la pince (seulement à l'aller)
        if not is_return and obstacle_sensor.distance() < 50 and a == 0:
            robot.stop()
            gripper_motor.run_target(400, -700)  # Fermer la pince
            wait(500)
            a = 1

    robot.stop()

# Programme principal
if __name__ == '__main__':
    # Création de la grille
    n = 4
    m = 4
    g = Grid(n, m)

    # Ajout des nœuds
    a = Node('A')
    b = Node('B')
    c = Node('C')
    d = Node('D')
    e = Node('E')
    f = Node('F')

    g.add_node(a)
    g.add_node(b)
    g.add_node(c)
    g.add_node(d)
    g.add_node(e)
    g.add_node(f)

    # Ajout des arêtes
    try:
        g.add_edge(a, b, 790, 'right')
        g.add_edge(b, c, 450, 'up')
        g.add_edge(c, d, 370, 'left')
        g.add_edge(d, e, 1400, 'down')
        g.add_edge(e, f, 320, 'right')
    except ValueError as e:
        ev3.screen.clear()
        ev3.screen.print("Erreur grille:")
        ev3.screen.print(str(e))
        wait(5000)
        raise SystemExit

    # Chemin à suivre
    path = [g.node_of('A'), g.node_of('B'), g.node_of('C'), 
            g.node_of('D'), g.node_of('E'), g.node_of('F')]

    # Démarrage du robot
    ev3.screen.clear()
    ev3.screen.print("Début aller")
    ev3.speaker.beep()

    # Parcours aller (A -> F)
    for idx, node in enumerate(path[1:]):
        print(previous_node = path[idx])
        direction = previous_node.direction_to_neighbor(node)
        distance = previous_node.distance_to_neighbor(node)
        follow_segment(previous_node, node, direction, distance, is_return=False)

        # Tourner à droite à l'arrivée au nœud F
        if node.get_idx() == 'F':
            ev3.screen.clear()
            ev3.screen.print("Tourne droite F")
            robot.turn(90)  # Tourner à droite de 90 degrés
            wait(500)

    # Déposer l'objet au point F
    ev3.screen.clear()
    ev3.screen.print("Dépôt objet")
    gripper_motor.run_target(400, 0)  # Ouvrir la pince
    wait(1000)

    # Parcours retour (F -> A)
    ev3.screen.print("Début retour")
    ev3.speaker.beep()
    reversed_path = path[::-1]  # Inverser le chemin
    
    for idx, node in enumerate(reversed_path[1:]):
        previous_node = reversed_path[idx]
        print(path[idx], node)
        direction = previous_node.direction_to_neighbor(node)
        distance = previous_node.distance_to_neighbor(node)
        follow_segment(previous_node, node, direction, distance, is_return=True)

    # Fin du parcours
    ev3.screen.clear()
    ev3.screen.print("Retour terminé")
    ev3.speaker.beep()
    wait(2000)